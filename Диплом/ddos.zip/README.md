# Система автоматического реагирования на DDoS-атаки

Анализирует nginx/apache access.log, обнаруживает DDoS-атаки двумя методами и автоматически блокирует атакующих через iptables.

---

## Быстрый старт

```bash
git clone <repo>
cd vkr_a4_ddos
./run.sh all
```

При первом запуске автоматически создаётся виртуальное окружение и устанавливаются зависимости.

---

## Команды run.sh

| Команда | Что делает |
|---|---|
| `./run.sh all` | Генерация лога + анализ + тесты |
| `./run.sh generate` | Сгенерировать тестовый `test_access.log` |
| `./run.sh analyze` | Проанализировать `test_access.log` |
| `./run.sh test` | Запустить все 22 теста |
| `./run.sh live` | Симулировать живой трафик → `live.log` |
| `./run.sh watch` | Мониторить `live.log` в реальном времени |

---

## Режимы работы

### 1. Анализ готового лог-файла

```bash
./run.sh generate   # создать тестовый лог
./run.sh analyze    # проанализировать
```

Или напрямую с параметрами:

```bash
.venv/bin/python main.py file /var/log/nginx/access.log --method both --dry-run
```

### 2. Мониторинг в реальном времени

Открыть **два терминала**:

```bash
# Терминал 1 — симуляция трафика (атака через 20 сек)
./run.sh live

# Терминал 2 — детектирование и блокировка
./run.sh watch
```

Для мониторинга реального nginx-лога:

```bash
.venv/bin/python main.py watch /var/log/nginx/access.log --method both --interval 10
```

> **Внимание:** без `--dry-run` система реально применяет `iptables`. Требует `sudo`.

---

## Параметры main.py

```
main.py <mode> <log> [опции]

Позиционные аргументы:
  mode        file — анализ файла, watch — реальный режим
  log         путь к лог-файлу

Опции:
  --method    statistical | isolation_forest | both  (по умолчанию: both)
  --dry-run   не применять iptables, только логировать
  --interval  интервал проверки в watch-режиме, секунды (по умолчанию: 10)
```

Примеры:

```bash
# Только статистический метод, реальная блокировка
sudo .venv/bin/python main.py file access.log --method statistical

# Isolation Forest, dry-run, интервал 5 сек
.venv/bin/python main.py watch live.log --method isolation_forest --dry-run --interval 5
```

---

## Параметры generate_logs.py

```bash
.venv/bin/python generate_logs.py --output access.log --duration 10 --attack-rps 200
```

| Параметр | По умолчанию | Описание |
|---|---|---|
| `--output` | `test_access.log` | Имя выходного файла |
| `--duration` | `10` | Длительность лога в минутах |
| `--attack-rps` | `200` | Интенсивность атаки (запросов/сек) |

Атака вшивается с 3-й по 7-ю минуту от начала лога.

---

## Параметры simulate_live.py

```bash
.venv/bin/python simulate_live.py --log live.log --attack-after 20 --attack-rps 50
```

| Параметр | По умолчанию | Описание |
|---|---|---|
| `--log` | `live.log` | Файл для записи трафика |
| `--attack-after` | `20` | Через сколько секунд начать атаку |
| `--attack-rps` | `50` | Интенсивность атаки (запросов/сек) |

---

## Структура проекта

```
vkr_a4_ddos/
├── main.py             # точка входа, CLI
├── log_analyzer.py     # парсинг логов, метрики по IP
├── detector.py         # статистический детектор + Isolation Forest
├── responder.py        # блокировка через iptables
├── generate_logs.py    # генератор тестовых логов
├── simulate_live.py    # симулятор живого трафика
├── run.sh              # скрипт управления
├── requirements.txt
└── tests/
    └── test_system.py  # 22 теста
```

---

## Как работает детектор

**Статистический метод** — вычисляет RPS (запросов/сек) для каждого IP и сравнивает с медианой через MAD-нормированный z-score. Устойчив к выбросам в отличие от обычного среднего.

- z ≥ 3.0 → **ATTACK** (блокировка)
- z ≥ 2.0 → **SUSPICIOUS** (только лог)

**Isolation Forest** — алгоритм машинного обучения, обнаруживает аномалии по 5 признакам: RPS, количество запросов, доля ошибок, уникальные пути, уникальные User-Agent.

- anomaly score < −0.1 → **ATTACK**
- anomaly score < 0 → **SUSPICIOUS**

---

## Реальная блокировка (production)

По умолчанию система работает в `--dry-run` режиме и не трогает iptables. Для реальной блокировки:

```bash
sudo .venv/bin/python main.py watch /var/log/nginx/access.log --method statistical --interval 10
```

Заблокированные IP автоматически разблокируются через 300 секунд (5 минут).

Добавить IP в белый список — отредактировать `responder.py`:

```python
WHITELIST: Set[str] = {"127.0.0.1", "::1", "ВАШ_IP"}
```
